
# Hyperparameter flags ---------------------------------------------------

FLAGS <- flags(
  flag_numeric("dropout1", 0.25),
  flag_numeric("dropout2", 0.5),
  flag_integer("hidden1",64),
  flag_integer("hidden2",128),
  flag_integer("hidden3",16),
  flag_numeric("l1",0.0001),
  flag_numeric("l2",0.0001)
)


# Define Model --------------------------------------------------------------

features.0 <- layer_input(shape=c(ncol(XlearnNN)))         # define network for features
net <- features.0 %>%
  #on ajoute kernel initialize direct dans le dense layer
  layer_dense(units = FLAGS$hidden1,activation="relu",kernel_initializer = initializer_he_normal(seed=100L),kernel_regularizer = regularizer_l1_l2(l1 = FLAGS$l1, l2 = FLAGS$l2)) %>% 
  layer_batch_normalization() %>%
  layer_dropout(FLAGS$dropout1) %>% 
  layer_dense(units = FLAGS$hidden2,activation="relu",kernel_initializer = initializer_he_normal(seed=200L),kernel_regularizer = regularizer_l1_l2(l1 = FLAGS$l1, l2 = FLAGS$l2)) %>% 
  layer_batch_normalization() %>%
  layer_dropout(FLAGS$dropout2) %>% 
  layer_dense(units = FLAGS$hidden3,activation="relu",kernel_initializer = initializer_he_normal(seed=300L),kernel_regularizer = regularizer_l1_l2(l1 = FLAGS$l1, l2 = FLAGS$l2)) %>% 
  layer_batch_normalization() %>%
  layer_dense(units = 1, activation = k_exp,kernel_initializer = initializer_he_normal(seed=400L))
volumes.0 <- layer_input(shape=c(1))                     # define network for offset
offset <- volumes.0 %>%
  layer_dense(units = 1, activation = 'linear', use_bias=FALSE, trainable=FALSE, weights=list(array(1, dim=c(1,1))))
merged <- list(net, offset) %>%                          # combine the two networks
  layer_multiply() 
model <- keras_model(inputs=list(features.0, volumes.0), outputs=merged)

model %>% compile(loss = Poisson.Deviance, optimizer = "nadam")

# Training & Evaluation ----------------------------------------------------

history <- model %>% fit(list(XlearnNN, WlearnNN), 
                         YlearnNN,
                         validation_data=list(list(XvalNN,WvalNN),YvalNN),
                         epochs=1000, 
                         batch_size=8192,
                         callbacks=list(
                           callback_early_stopping(patience=25,restore_best_weights = T),
                           callback_reduce_lr_on_plateau(factor=0.05))
)

data_fit <- as.data.frame(history)


ggplot(data_fit[which(!is.na(data_fit$value)),],aes(x=epoch,y=value,col=data))+
  geom_point()

score <- model %>% evaluate(
  list(XtestNN,WtestNN), YtestNN,
  verbose = 0
)

name_deep3 <- c(name_deep3,"64_128_16_drop_0.25_0.5_l1l2_0.0001")

out_loss_deep3 <- c(out_loss_deep3,unname(score[1]))
val_loss3 <- c(val_loss3,min(history[["metrics"]][["val_loss"]]))
results_deep3 <- data.frame(name_deep3,out_loss_deep3,val_loss3)
results_deep3
