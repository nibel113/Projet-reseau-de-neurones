library(tfruns)
library(recipes)     # Library for data processing
library(glue)        # For conveniently concatenating strings
library(zeallot)  
source("Pre-traitement.R")

runs <- tuning_run("Deep_3hidden_tuning.R", sample = 0.4, 
                   runs_dir = "Deep3_tuning_nb_neurone",
                   flags = list(
                     dropout1 = c(0),
                     dropout2 = c(0),
                     hidden1=c(16,32,64,128),
                     hidden2=c(32,64,128,256),
                     hidden3=c(16,32,64),
                     l1_1=c(0),
                     l2_1=c(0),
                     l1_2=c(0),
                     l2_2=c(0),
                     l1_3=c(0),
                     l2_3=c(0))
)


